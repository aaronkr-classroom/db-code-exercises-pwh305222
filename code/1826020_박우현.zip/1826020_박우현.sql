-- 1. CREATE TABLES
-- 기본 코드 테이블

CREATE TABLE class_code (
    code int PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

CREATE TABLE task_code (
    code int PRIMARY KEY,
    task VARCHAR(30)
);

-- 엔티티 테이블

CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cell CHAR(13) NOT NULL UNIQUE,
    addr VARCHAR(100),
    C_Code int DEFAULT 3
);

CREATE TABLE staff (
    staff_id int PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday int NOT NULL,
    tel varCHAR(12),
    salary int,
    t_code int NOT NULL,
    hire_date varCHAR(8) NOT NULL
);

CREATE TABLE tour (
    tour_num varCHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num int,
    max_num int,
    expense int NOT NULL,
    deposit int,
    dept_yn varCHAR(1) DEFAULT 'N',
    staff_id int,
    FOREIGN KEY(staff_id) REFERENCES staff(staff_id)
);

CREATE TABLE reserve (
    cus_id VARCHAR(15),
    tour_num varCHAR(8),
    res_date varCHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn varCHAR(1) DEFAULT 'N',
    exp_yn varCHAR(1) DEFAULT 'N',
    PRIMARY KEY(cus_id, tour_num),
    FOREIGN KEY(cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY(tour_num) REFERENCES tour(tour_num)
);

-- 보너스 테이블

CREATE TABLE tour_bus (
    bus_id int PRIMARY KEY,
    seat int,
    del_yesr int
);

CREATE TABLE driver (
    driver_id int PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday varCHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay int DEFAULT 15000,
    cont_date varCHAR(8),
    cont_term varCHAR(8)
);

CREATE TABLE assign_driver (
    tour_num varCHAR(8) PRIMARY KEY,
    driver_id int,
    work_hour int,
    FOREIGN KEY(tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY(driver_id) REFERENCES driver(driver_id)
);

CREATE TABLE assign_bus (
    tour_num varCHAR(8) PRIMARY KEY,
    bus_id int,
    FOREIGN KEY(tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY(bus_id) REFERENCES tour_bus(bus_id)
);

-- 2. INSERT DATA 

INSERT INTO class_code VALUES (1, '최우수', 'VVIP');
INSERT INTO class_code VALUES (2, '우수', 'VIP');
INSERT INTO class_code VALUES (3, '일반', '일반');

INSERT INTO task_code VALUES (1, '여행상품관리');
INSERT INTO task_code VALUES (2, '예약관리');
INSERT INTO task_code VALUES (3, '관광버스배차관리');
INSERT INTO task_code VALUES (4, '직원관리');
INSERT INTO task_code VALUES (5, '고객관리');

INSERT INTO customer VALUES ('C001', '김', '010-1111-1111', '서울', 1);
INSERT INTO customer VALUES ('C002', '이', '010-2222-2222', '부산', 2);
INSERT INTO customer VALUES ('C003', '박', '010-3333-3333', '천안', 3);
INSERT INTO customer VALUES ('C004', '정', '010-4444-4444', '인천', 3);
INSERT INTO customer VALUES ('C005', '강', '010-5555-5555', '청주', 2);

INSERT INTO staff VALUES (101, '김부장', 800101, '010-99999999', 5000000, 1, '20200101');
INSERT INTO staff VALUES (102, '이과장', 871225, '010-88888888', 4000000, 2, '20210201');
INSERT INTO staff VALUES (103, '박대리', 900122, '010-77777777', 3000000, 3, '20220301');
INSERT INTO staff VALUES (104, '정사원', 930411, '010-66666666', 2500000, 4, '20230401');
INSERT INTO staff VALUES (105, '강인턴', 990305, '010-55555555', 2000000, 5, '20240501');

INSERT INTO tour VALUES ('T001', '서울', '제주', '제주힐링', TO_DATE('20260701','YYYYMMDD'), TO_DATE('20260703','YYYYMMDD'), 10, 30, 500000, 50000, 'N', 101);
INSERT INTO tour VALUES ('T002', '서울', '부산', '부산투어', TO_DATE('20260801','YYYYMMDD'), TO_DATE('20260802','YYYYMMDD'), 5, 20, 300000, 30000, 'N', 102);

INSERT INTO reserve VALUES ('C001', 'T001', 'Y', 'Y');
INSERT INTO reserve VALUES ('C002', 'T001', 'Y', 'N');
INSERT INTO reserve VALUES ('C003', 'T002', 'N', 'N');
INSERT INTO reserve VALUES ('C004', 'T002', 'Y', 'N');
INSERT INTO reserve VALUES ('C005', 'T001', 'N', 'N');

-- 3. INDEX

CREATE INDEX tour_arrival_idx ON tour(arrival);
CREATE INDEX driver_name_idx ON driver(name);

-- 4. TEST QUERIES
-- 고객 등급 검색

SELECT c.name, cl.class 
FROM customer c JOIN class_code cl ON c.C_Code = cl.code 
WHERE c.cus_id = 'C001';

-- 직원 담당업무 검색

SELECT s.name, t.task 
FROM staff s JOIN task_code t ON s.t_code = t.code 
WHERE s.staff_id = 101;

-- 여행상품 예약 고객 검색

SELECT c.name, r.res_date, r.dep_yn 
FROM reserve r JOIN customer c ON r.cus_id = c.cus_id 
WHERE r.tour_num = 'T001';

-- 여행상품에 배정된 운전기사 검색

SELECT t.departure, d.name, d.cell 
FROM tour t 
JOIN assign_driver ad ON t.tour_num = ad.tour_num 
JOIN driver d ON ad.driver_id = d.driver_id 
WHERE t.tour_num = 'T001';

-- 고객 데이터 삽입

INSERT INTO customer VALUES ('C006', '현현', '010-6666-6666', '전주', 3);

-- 직원 급여 변경

UPDATE staff SET salary = salary + 200000 WHERE staff_id = 101;

-- 예약 정보 삭제

DELETE FROM reserve WHERE cus_id = 'C001' AND tour_num = 'T001';

-- 5. 삭제

DROP TABLE class_code;
DROP TABLE task_code;
DROP TABLE customer;
DROP TABLE staff;
DROP TABLE tour;
DROP TABLE reserve;
DROP TABLE tour_bus;
DROP TABLE driver;
DROP TABLE assign_driver;
DROP TABLE assign_bus;